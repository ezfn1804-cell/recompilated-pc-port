import test from 'node:test';
import assert from 'node:assert/strict';
import {Simulation,CITY,VEHICLES,onRoad,routeBetween,trafficLightAt} from '../src/simulation.js';
const step=(sim,seconds,input)=>{for(let n=0;n<Math.ceil(seconds*120);n++)sim.update(1/120,input);};
const empty=sim=>{sim.traffic=[];sim.police=[];sim.policeSpawnTime=1000;sim.wanted=0;sim.escapeCooldown=1000;};
test('every grid route remains connected and on drivable streets',()=>{
 const path=routeBetween({x:-600,z:600},{x:600,z:-600});assert.equal(path.length,17);for(let i=1;i<path.length;i++){assert.equal(Math.abs(path[i].x-path[i-1].x)+Math.abs(path[i].z-path[i-1].z),150);assert.ok(onRoad(path[i].x,path[i].z));}
 assert.equal(onRoad(65,65),false);assert.equal(onRoad(0,67),true);assert.equal(CITY.spacing,150);
});
test('accelerating, braking, reversing and finite nitro behave consistently',()=>{
 const s=new Simulation();s.start('velocity',12);empty(s);s.car.z=590;
 step(s,2,{throttle:1});assert.ok(s.car.speed>70);const speed=s.car.speed;
 step(s,.6,{throttle:1,nitro:true});assert.ok(s.car.speed>speed);assert.ok(s.car.nitro<100&&s.car.nitro>70);assert.equal(s.car.boosting,true);
 step(s,2,{brake:true});assert.ok(s.car.speed<10);assert.ok(s.car.speed>=-23.01);assert.ok(s.car.health>0);assert.ok(Number.isFinite(s.car.x));
});
test('same seed and inputs reproduce the same simulation',()=>{
 const a=new Simulation(),b=new Simulation();a.start('interceptor',88);b.start('interceptor',88);
 step(a,3,{throttle:1});step(b,3,{throttle:1});assert.deepEqual(a.car,b.car);assert.equal(a.traffic[0].x,b.traffic[0].x);assert.equal(a.police[0].z,b.police[0].z);
});
test('buildings stop the player; recovery has a bounded cost',()=>{
 const s=new Simulation();s.start();empty(s);s.car.x=15;s.car.z=75;s.car.heading=Math.PI/2;s.car.vx=90;s.car.vz=0;s.score=1000;
 step(s,.1,{throttle:1});assert.ok(onRoad(s.car.x,s.car.z,2));assert.ok(s.car.health<100&&s.car.health>70);assert.ok(s.recover());assert.equal(s.car.speed,0);assert.equal(s.score,850);assert.equal(s.recover(),false);assert.ok(s.car.health>0);
});
test('checkpoints repair, refill and relocate to another reachable junction',()=>{
 const events=[],s=new Simulation({onEvent:e=>events.push(e)});s.start('enforcer',35);empty(s);s.car.x=s.checkpoint.x;s.car.z=s.checkpoint.z;s.car.health=50;s.car.nitro=10;
 s.update(1/120,{});assert.equal(s.checkpoints,1);assert.ok(s.car.health>=64);assert.ok(s.car.nitro>=48);assert.ok(s.score>=900);assert.ok(events.some(e=>e.type==='checkpoint'));assert.ok(onRoad(s.checkpoint.x,s.checkpoint.z));assert.ok(Math.hypot(s.checkpoint.x-s.car.x,s.checkpoint.z-s.car.z)>300);
});
test('stationary player is captured, pause freezes time and end is reported once',()=>{
 const events=[],s=new Simulation({onEvent:e=>events.push(e)});s.start();s.traffic=[];s.car.x=0;s.car.z=0;s.police=[{id:900,x:0,z:9,heading:0,speed:0,maxSpeed:0,role:'hunter',color:0,path:[{x:0,z:0}],nextRoute:999,hitTime:999,age:0,stuck:0,lastX:0,lastZ:9}];s.policeSpawnTime=999;
 s.pause();const time=s.time;step(s,1,{throttle:1});assert.equal(s.time,time);s.pause();
 step(s,7,{});assert.equal(s.state,'over');assert.ok(s.busted>=1);assert.equal(events.filter(e=>e.type==='result').length,1);step(s,1,{});assert.equal(events.filter(e=>e.type==='result').length,1);
});
test('traffic and pursuit update for long runs with finite bounded positions',()=>{
 const s=new Simulation();s.start('interceptor',342);s.car.health=1e6;s.car.maxHealth=1e6;
 for(let i=0;i<2400;i++){if(s.state!=='play')break;const phase=i%600;s.update(1/120,{throttle:1,steer:phase>500?.2:0,handbrake:phase>500,nitro:phase<120});if(i%700===699)s.recover();}
 assert.ok(s.time>19);assert.ok(s.traffic.length<=68);assert.ok(s.police.length<=9);for(const npc of [...s.traffic,...s.police]){assert.ok(Number.isFinite(npc.x)&&Number.isFinite(npc.z));assert.ok(onRoad(npc.x,npc.z,1));}assert.ok(s.stats.topSpeed>40);
});
test('traffic lights have alternating drive phases and a red clearance interval',()=>{
 const values=new Set(Array.from({length:170},(_,i)=>trafficLightAt(0,0,i*.1)));assert.deepEqual(values,new Set(['ns','all-red','ew']));assert.equal(VEHICLES.velocity.maxSpeed>VEHICLES.interceptor.maxSpeed,true);
});
test('NPCs keep progressing through junctions for a full minute without entering blocks',()=>{
 const s=new Simulation();s.start('interceptor',44);const npcs=[...s.traffic,...s.police],records=new Map(npcs.map(v=>[v.id,{node:JSON.stringify(v.path[0]),visits:0,moved:0,x:v.x,z:v.z}]));
 // Isolate navigation from the player capture timer and collisions. Target moves on a real road.
 for(let tick=0;tick<60*120;tick++){
  s.time+=1/120;s.car.x=6.5;s.car.z=400-(s.time*60)%950;s.car.vx=0;s.car.vz=-60;s.car.speed=60;
  for(const npc of npcs){s.updateNpc(npc,1/120,!!npc.role);assert.ok(onRoad(npc.x,npc.z,1),`NPC ${npc.id} entered a block`);const r=records.get(npc.id),node=JSON.stringify(npc.path[0]);r.moved+=Math.hypot(npc.x-r.x,npc.z-r.z);r.x=npc.x;r.z=npc.z;if(node!==r.node){r.visits++;r.node=node;}}
 }
 for(const npc of npcs){const r=records.get(npc.id);assert.ok(r.visits>=3,`NPC ${npc.id} did not advance through junctions`);assert.ok(r.moved>350,`NPC ${npc.id} remained stuck`);}
});
test('interceptor predicts the fast player next junction instead of copying the hunter route',()=>{
 const s=new Simulation();s.start('interceptor',81);s.car.x=6.5;s.car.z=75;s.car.vx=0;s.car.vz=-100;s.car.speed=100;
 const hunter={x:-150,z:300,heading:0,role:'hunter'},interceptor={...hunter,role:'interceptor'};s.policePath(hunter);s.policePath(interceptor);
 assert.notDeepEqual(hunter.path.at(-1),interceptor.path.at(-1));assert.ok(interceptor.path.at(-1).z<hunter.path.at(-1).z);
});
test('braking into a handbrake turn can exit an intersection at 90 degrees without hitting walls',()=>{
 const s=new Simulation();s.start();empty(s);s.car.x=6.5;s.car.z=70;s.car.vx=0;s.car.vz=-65;s.car.speed=65;
 step(s,.5,{brake:true});for(let n=0;n<145;n++)s.update(1/120,{});
 for(let n=0;s.car.heading<1.1&&n<240;n++)s.update(1/120,{steer:1,handbrake:true});
 for(let n=0;n<360;n++){const error=Math.atan2(Math.sin(Math.PI/2-s.car.heading),Math.cos(Math.PI/2-s.car.heading));s.update(1/120,{steer:Math.max(-1,Math.min(1,error*2)),throttle:1});}
 assert.ok(s.car.x>150);assert.ok(Math.abs(s.car.z)<=CITY.roadHalf-2);assert.ok(Math.abs(s.car.heading-Math.PI/2)<.03);assert.equal(s.stats.collisions,0);assert.equal(s.car.health,100);
});
test('capture pressure falls when the driver gets away and normal acceleration respects the speed cap',()=>{
 const s=new Simulation();s.start();empty(s);s.car.z=600;s.car.vz=-60;s.car.speed=60;s.busted=.5;step(s,.75,{throttle:1});assert.ok(s.busted<.35);step(s,3,{throttle:1});assert.ok(s.car.speed<=VEHICLES.interceptor.maxSpeed+.01);
});
