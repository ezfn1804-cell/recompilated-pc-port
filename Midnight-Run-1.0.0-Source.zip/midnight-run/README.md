# MIDNIGHT RUN

Jeu de conduite arcade **3D à la troisième personne** : supercar, nitro, circulation urbaine et poursuites de police. Ce sous-projet conserve le précédent NEON RIFT dans le dépôt parent.

## Jouer sur Windows

`release/Midnight-Run-1.0.0-Windows-x64.exe` est l’exécutable portable Windows 10 / 11 **64 bits** produit par la compilation. Double-cliquez dessus ; aucune installation de Node.js ni connexion n’est nécessaire pour jouer. Le premier lancement extrait le moteur dans un répertoire temporaire.

Le fichier de développement n’est pas signé. La compilation croisée sous Linux ne prouve pas le lancement natif sous Windows. `SHA256SUMS.txt` permet de vérifier le fichier distribué ; les licences accompagnent le jeu et sont embarquées dans l’application.

| Action | Commande |
| --- | --- |
| Accélérer / freiner ou reculer | Z/S, W/S ou flèches haut/bas |
| Diriger | Q/D, A/D ou flèches gauche/droite |
| Frein à main / drift | Espace |
| Nitro | Maj |
| Caméra | C |
| Remettre la voiture sur la route | R |
| Pause | Échap |
| Plein écran | F11 ou bouton plein écran |

WebGL2 et l’accélération graphique sont requis. Les options graphiques permettent d’adapter la charge au PC. Les points de passage se renouvellent tant que la voiture survit à la poursuite. La ville utilise un réseau de rues de 1,2 km de côté, avec des quartiers, parcs et bâtiments procéduraux.

## Développer

Node.js **24** recommandé. Depuis ce répertoire :

```sh
npm ci
npm run dev
npm test
npm run test:e2e
npm run build
npm run desktop
npm run dist:win
```

- `npm run dev` : serveur de développement, port **5180**.
- `npm run preview` : version compilée, port **5181**.
- `npm test` : tests de simulation et règles dans `tests/`.
- `npm run test:e2e` : vérifications navigateur Playwright (Chromium système ou navigateur installé par `npx playwright install chromium`).
- `npm run build` : version navigateur dans `dist/`, chemins relatifs adaptés à Electron.
- `npm run desktop` : compile puis lance Electron sur la plateforme courante.
- `npm run dist:win` : `.exe` portable, empreinte SHA-256 et notices dans `release/`.

Le script de packaging fonctionne aussi avec les dépendances déjà installées dans le projet parent. Pour reproduire l’environnement indépendamment, utilisez `npm ci` dans ce sous-projet. En compilation croisée uniquement, `ELECTRON_SKIP_BINARY_DOWNLOAD=1 npm ci` évite le téléchargement du moteur de la plateforme hôte ; Electron Builder télécharge ensuite le moteur Windows officiel.

La compression Windows utilise le niveau 7 par défaut, modifiable via `ELECTRON_BUILDER_COMPRESSION_LEVEL`. Une diffusion par commit Git sur GitHub impose un fichier **strictement inférieur à 100 Mio** ; le script signale tout dépassement. Les assets de Releases sont un autre canal, lorsque leurs accès sont disponibles. Aucun envoi réseau du jeu n’est déclenché par les scripts de compilation.

Les polices Barlow Condensed et Space Grotesk, ainsi que Three.js, sont distribués avec leurs licences dans `desktop/THIRD_PARTY_NOTICES.txt`. Aucun jeton, compte joueur ou service externe n’est requis pendant la partie.


## Conduite et poursuite

Trois configurations : APEX GT (équilibrée), VOLT R (jusqu’à environ 598 km/h avec nitro) et BRUTE V8 (plus résistante). Freinez avant de tourner ; le frein à main permet de glisser dans les intersections. Les collisions réduisent la carrosserie, la police peut vous capturer si vous restez à faible vitesse à proximité.

Les 68 véhicules de circulation suivent les rues, cèdent aux feux et évitent leurs leaders. La police utilise des routes A* : les chasseurs suivent, les intercepteurs visent une intersection future et les unités agressives cherchent le contact. Les niveaux de recherche ajoutent des unités et des barrages. Casser la ligne de vue pendant onze secondes permet de semer la poursuite.

Les checkpoints réparent 14 points de carrosserie et rechargent 38 points de nitro. Drift et frôlements construisent un multiplicateur jusqu’à ×5. Les records de score et de vitesse sont sauvegardés localement. Le mode « Même ville » rejoue la même graine ; vos actions changent la poursuite.

Les tests de simulation couvrent accélération, freinage, nitro, collisions, réparation, capture, routage, interception, circulation pendant 60 secondes et virage à 90°. Les tests Chromium couvrent menu, conduite, caméra derrière le véhicule, pause, résultats, sauvegarde, tactile et fichiers de production sans accès externe. Les tests accélérés ne constituent pas une mesure de performances sur un PC de jeu. Le lancement natif Windows et les manettes physiques restent à vérifier sur les appareils correspondants.
