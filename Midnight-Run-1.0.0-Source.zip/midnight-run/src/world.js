import * as THREE from 'three';
import {mergeGeometries} from 'three/addons/utils/BufferGeometryUtils.js';
import {EffectComposer} from 'three/addons/postprocessing/EffectComposer.js';
import {RenderPass} from 'three/addons/postprocessing/RenderPass.js';
import {UnrealBloomPass} from 'three/addons/postprocessing/UnrealBloomPass.js';
import {CITY,trafficLightAt} from './simulation.js';

const TAU=Math.PI*2,UP=new THREE.Vector3(0,1,0),v=new THREE.Vector3(),dummy=new THREE.Object3D();
const PALETTE=[0xe95528,0x199fad,0xf7bd57,0xc8d4e0,0x713cc0,0x244b73,0xe3e9ed,0x252c3b];
const smooth=(rate,dt)=>1-Math.exp(-rate*dt);
const random=i=>{const x=Math.sin(i*127.13+11.21)*43758.5453;return x-Math.floor(x);};
function standard(color,roughness=.4,metalness=.4){return new THREE.MeshStandardMaterial({color,roughness,metalness});}
function lit(color){return new THREE.MeshBasicMaterial({color,toneMapped:false});}
function loft(stations){
 const vertices=[],indices=[];
 for(const s of stations){vertices.push(-s.w,s.b,s.z,s.w,s.b,s.z,s.w*.89,s.h,s.z,-s.w*.89,s.h,s.z);}
 for(let n=0;n<stations.length-1;n++){for(let k=0;k<4;k++){const a=n*4+k,b=n*4+(k+1)%4,c=b+4,d=a+4;indices.push(a,b,d,b,c,d);}}
 indices.push(0,3,1,1,3,2);const e=(stations.length-1)*4;indices.push(e,e+1,e+3,e+1,e+2,e+3);
 const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(vertices,3));g.setIndex(indices);g.computeVertexNormals();return g;
}
export class DrivingWorld{
 constructor(canvas){
  this.canvas=canvas;this.scene=new THREE.Scene();this.scene.background=new THREE.Color(0x13263d);this.scene.fog=new THREE.Fog(0x253644,160,690);this.time=0;this.quality='balanced';this.motion=!matchMedia('(prefers-reduced-motion: reduce)').matches;this.shake=0;this.particles=[];this.entities=new Map();this.barriers=new Map();this.disposed=false;this.cameraInitialized=false;this.vehicle='interceptor';
  this.renderer=new THREE.WebGLRenderer({canvas,antialias:true,powerPreference:'high-performance'});this.renderer.toneMapping=THREE.ACESFilmicToneMapping;this.renderer.toneMappingExposure=1.05;
  this.camera=new THREE.PerspectiveCamera(66,innerWidth/innerHeight,.15,1900);this.camera.position.set(13,6,90);this.cameraTarget=new THREE.Vector3();
  this.composer=new EffectComposer(this.renderer);this.composer.addPass(new RenderPass(this.scene,this.camera));this.bloom=new UnrealBloomPass(new THREE.Vector2(innerWidth,innerHeight),.45,.45,.85);this.composer.addPass(this.bloom);
  this.scene.add(new THREE.HemisphereLight(0x9dc9ff,0x46323c,1.7));this.sun=new THREE.DirectionalLight(0xffb578,2.2);this.sun.position.set(-230,200,-400);this.scene.add(this.sun);const carFill=new THREE.DirectionalLight(0xb1ceef,.65);carFill.position.set(40,55,90);this.scene.add(carFill);
  this.geo={box:new THREE.BoxGeometry(1,1,1),plane:new THREE.PlaneGeometry(1,1),sphere:new THREE.SphereGeometry(1,12,8),cylinder:new THREE.CylinderGeometry(1,1,1,12),ring:new THREE.TorusGeometry(1,.05,6,64)};
  this.mat={asphalt:standard(0x172231,.36,.25),sidewalk:standard(0x394454,.7,.15),carbon:standard(0x101720,.36,.65),glass:standard(0x0a2031,.12,.8),rubber:standard(0x0b0d12,.9,.05),chrome:standard(0xc0cfdb,.24,.85),orange:lit(0xff7738),cyan:lit(0x62ddff),white:lit(0xf5e5ca),red:lit(0xff2d46),blue:lit(0x2288ff),yellow:lit(0xffc257),park:standard(0x1f3d36,.95,.05)};
  this.templates=new Map();this.buildings=[];this.disposables=[];this.buildSky();this.buildCity();
  this.player=this.makeCar('player',PALETTE[0]);this.scene.add(this.player);this.checkpoint=this.makeCheckpoint();this.scene.add(this.checkpoint);
  this.particleMesh=new THREE.InstancedMesh(this.geo.box,lit(0xffa46c),180);this.particleMesh.count=0;this.particleMesh.frustumCulled=false;this.particleMesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);this.scene.add(this.particleMesh);
  this.trailPositions=new Float32Array(600*6);this.trailGeometry=new THREE.BufferGeometry();this.trailGeometry.setAttribute('position',new THREE.BufferAttribute(this.trailPositions,3).setUsage(THREE.DynamicDrawUsage));this.trailGeometry.setDrawRange(0,0);this.trails=new THREE.LineSegments(this.trailGeometry,new THREE.LineBasicMaterial({color:0x0a1018,transparent:true,opacity:.72}));this.trails.frustumCulled=false;this.scene.add(this.trails);this.trailIndex=0;this.trailCount=0;this.previousWheel=null;
  this.resize();
 }
 mesh(geometry,material,parent=this.scene){const m=new THREE.Mesh(geometry,material);parent.add(m);return m;}
 box(material,size,pos,parent=this.scene){const m=this.mesh(this.geo.box,material,parent);m.scale.set(...size);m.position.set(...pos);return m;}
 instanced(geometry,material,items){if(!items.length)return;const mesh=new THREE.InstancedMesh(geometry,material,items.length);for(let i=0;i<items.length;i++){const a=items[i];dummy.position.set(...a.p);dummy.rotation.set(0,a.r||0,0);dummy.scale.set(...a.s);dummy.updateMatrix();mesh.setMatrixAt(i,dummy.matrix);}mesh.computeBoundingSphere();this.scene.add(mesh);return mesh;}
 buildSky(){
  const material=new THREE.ShaderMaterial({side:THREE.BackSide,depthWrite:false,uniforms:{},vertexShader:`varying vec3 dir;void main(){dir=position;vec4 p=projectionMatrix*modelViewMatrix*vec4(position,1.);gl_Position=p.xyww;}`,fragmentShader:`varying vec3 dir;void main(){vec3 d=normalize(dir);float h=max(d.y,0.);vec3 zenith=vec3(.025,.075,.17);vec3 horizon=vec3(.54,.26,.20);vec3 c=mix(horizon,zenith,smoothstep(0.,.55,h));float sun=pow(max(dot(d,normalize(vec3(-.45,.095,-.8))),0.),1800.);float glow=pow(max(dot(d,normalize(vec3(-.45,.095,-.8))),0.),12.);c+=vec3(1.,.66,.27)*sun*1.7+vec3(.2,.08,.015)*glow;c+=sin(d.x*45.+d.z*36.+d.y*100.)*.009*smoothstep(.05,.3,h);gl_FragColor=vec4(c,1.);}`});
  this.sky=this.mesh(new THREE.SphereGeometry(1600,24,16),material);this.sky.renderOrder=-10;this.sky.frustumCulled=false;
 }
 buildCity(){
  const uniforms={player:{value:new THREE.Vector2()},direction:{value:new THREE.Vector2(0,-1)},time:{value:0}};
  const roadMaterial=new THREE.ShaderMaterial({uniforms,vertexShader:`varying vec3 worldPos;void main(){vec4 p=modelMatrix*vec4(position,1.);worldPos=p.xyz;gl_Position=projectionMatrix*viewMatrix*p;}`,fragmentShader:`varying vec3 worldPos;uniform vec2 player;uniform vec2 direction;uniform float time;
float hash(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453);}
void main(){vec2 p=worldPos.xz;vec2 a=abs(mod(p+75.,150.)-75.);bool vertical=a.x<18.;bool horizontal=a.y<18.;float road=vertical||horizontal?1.:0.;float edge=min(abs(a.x-18.),abs(a.y-18.));vec3 c=vec3(.052,.072,.096);if(road>.5){float grain=hash(floor(p*7.))*.017;c=vec3(.035,.05,.073)+grain;float lane=vertical?a.x:a.y;float along=vertical?p.y:p.x;float dash=step(mod(along,18.),9.);float marks=(1.-smoothstep(.09,.17,abs(lane-8.)))*dash;float center=1.-smoothstep(.07,.13,abs(lane-.23));float side=1.-smoothstep(.08,.16,abs(lane-16.5));if(!(a.x<18.&&a.y<18.)){c+=vec3(.42,.47,.46)*marks+vec3(.65,.38,.10)*center+vec3(.28,.34,.39)*side;}float crossing=0.;if(vertical&&a.y>22.&&a.y<28.)crossing=step(mod(p.x+17.,3.),1.5);if(horizontal&&a.x>22.&&a.x<28.)crossing=max(crossing,step(mod(p.y+17.,3.),1.5));c+=crossing*.28;float reflect=pow(max(sin((vertical?p.y:p.x)*.053+sin((vertical?p.x:p.y)*4.)*.03),0.),35.);c+=vec3(.13,.065,.025)*reflect*.3;vec2 rel=p-player;float dist=length(rel);float cone=pow(max(dot(normalize(rel+vec2(.0001)),direction),0.),26.);c+=vec3(.34,.38,.40)*cone*exp(-dist*.045)*smoothstep(.5,5.,dist);float wet=pow(max(sin(p.x*.04+p.y*.013),0.),15.);c+=vec3(.025,.035,.055)*wet;}else{float curb=1.-smoothstep(.4,1.5,edge);c+=curb*.08;float seams=max(1.-smoothstep(.02,.07,abs(mod(p.x,4.)-2.)),1.-smoothstep(.02,.07,abs(mod(p.y,4.)-2.)));c-=seams*.008;}float fog=1.-exp(-length(p-player)*.002);c=mix(c,vec3(.12,.18,.23),fog*.72);gl_FragColor=vec4(c,1.);}`});
  this.road=this.mesh(new THREE.PlaneGeometry(1550,1550),roadMaterial);this.road.rotation.x=-Math.PI/2;this.road.position.y=-.03;
  const bodies=Array.from({length:6},()=>[]),caps=[],mechanicals=[],neons=[[],[]],windowFaces=[],treeTrunks=[],treeCrowns=[],lampPoles=[],lampArms=[],lampLights=[],bollards=[],parkTiles=[];
  const bodyMats=[0x273447,0x263342,0x364050,0x202f43,0x303b4c,0x253643].map(c=>standard(c,.55,.35));
  let id=0;const min=CITY.gridMin??-600,max=CITY.gridMax??600,spacing=CITY.spacing??150;
  for(let bx=min;bx<max;bx+=spacing)for(let bz=min;bz<max;bz+=spacing){
   const block=id++,park=(block%17===8);if(park){parkTiles.push({p:[bx+75,.03,bz+75],s:[99,.12,99]});for(let n=0;n<18;n++){const x=bx+30+random(block*40+n)*90,z=bz+30+random(block*40+n+5)*90,h=4+random(block+n)*3;treeTrunks.push({p:[x,h/2,z],s:[.5,h,.5]});treeCrowns.push({p:[x,h+1,z],s:[3+random(n)*2,4,3+random(n+10)*2]});}continue;}
   for(let ix=0;ix<2;ix++)for(let iz=0;iz<2;iz++){
    const seed=block*21+ix*5+iz*7,px=bx+45+ix*60,pz=bz+45+iz*60,w=32+random(seed+2)*15,d=32+random(seed+3)*15;let h=22+random(seed+8)*77;const center=Math.hypot(px,pz);if(center<350)h+=random(seed+20)*95;
    bodies[seed%6].push({p:[px,h/2,pz],s:[w,h,d]});caps.push({p:[px,h+.5,pz],s:[w+1,1,d+1]});mechanicals.push({p:[px+3,h+2,pz-4],s:[w*.3,3,d*.3]});this.buildings.push({x:px,z:pz,w:w/2,d:d/2,h});
    for(const [x,z,r,width]of [[px,pz+d/2+.18,0,w],[px,pz-d/2-.18,Math.PI,w],[px+w/2+.18,pz,Math.PI/2,d],[px-w/2-.18,pz,-Math.PI/2,d]])windowFaces.push({p:[x,h/2,z],s:[width,h,1],r});
    if(seed%3===0){neons[seed%2].push({p:[px,h*.7,pz+d/2+.1],s:[w,.16,.12]});neons[seed%2].push({p:[px-w/2-.1,h*.7,pz],s:[.12,.16,d]});}
    if(seed%11===0){const sign=this.makeSign(['MIDNIGHT','HOTEL','NIGHT CITY','ZENITH','NO LIMIT'][seed%5],seed%2?0x60dfff:0xff854a);sign.position.set(px,h*.52,pz+d/2+.2);sign.scale.set(Math.min(w-4,24),5,1);}
   }
  }
  bodies.forEach((items,i)=>this.instanced(this.geo.box,bodyMats[i],items));this.instanced(this.geo.box,this.mat.carbon,caps);this.instanced(this.geo.box,standard(0x4a5665),mechanicals);
  this.instanced(this.geo.box,this.mat.orange,neons[0]);this.instanced(this.geo.box,this.mat.cyan,neons[1]);this.instanced(this.geo.box,this.mat.park,parkTiles);
  this.instanced(this.geo.cylinder,standard(0x3a302e),treeTrunks);this.instanced(this.geo.sphere,standard(0x315647,.95,.05),treeCrowns);
  const windowMaterial=new THREE.ShaderMaterial({transparent:true,depthWrite:false,toneMapped:false,polygonOffset:true,polygonOffsetFactor:-1,polygonOffsetUnits:-2,vertexShader:`varying vec2 uvw;varying vec2 dims;varying float seed;void main(){uvw=uv;dims=vec2(length(instanceMatrix[0].xyz),length(instanceMatrix[1].xyz));seed=instanceMatrix[3].x+instanceMatrix[3].z;gl_Position=projectionMatrix*viewMatrix*modelMatrix*instanceMatrix*vec4(position,1.);}`,fragmentShader:`varying vec2 uvw;varying vec2 dims;varying float seed;float hash(vec2 p){p=floor(p+.5);vec3 q=fract(vec3(p.xyx)*.1031);q+=dot(q,q.yzx+33.33);return fract((q.x+q.y)*q.z);}void main(){vec2 cells=uvw*floor(dims+.5)/vec2(2.6,3.6);vec2 f=fract(cells);vec2 id=floor(cells);float sid=floor(seed+.5);float on=step(.32,hash(id+sid));float room=step(.22,f.x)*step(f.x,.76)*step(.24,f.y)*step(f.y,.69);if(room*on<.5)discard;float h=hash(id*2.+sid);vec3 c=mix(vec3(.10,.25,.34),vec3(.66,.38,.17),step(.72,h));c*=.45+hash(id+3.)*.45;gl_FragColor=vec4(c,.9);}`});this.instanced(this.geo.plane,windowMaterial,windowFaces);
  for(let a=min;a<=max;a+=spacing){for(let q=min+25;q<max;q+=75){for(const sign of [-1,1]){for(const swap of [false,true]){const x=swap?q:a+sign*20,z=swap?a+sign*20:q;lampPoles.push({p:[x,5,z],s:[.15,10,.15]});lampArms.push({p:[x+(swap?0:-sign*1.5),10,z+(swap?-sign*1.5:0)],s:swap?[.18,.18,3.2]:[3.2,.18,.18]});lampLights.push({p:[x+(swap?0:-sign*2.7),9.86,z+(swap?-sign*2.7:0)],s:swap?[.5,.08,1.1]:[1.1,.08,.5]});}}}}
  this.instanced(this.geo.box,standard(0x253b4f),lampPoles);this.instanced(this.geo.box,standard(0x273f52),lampArms);this.instanced(this.geo.box,this.mat.white,lampLights);
  // All traffic gantries share a handful of draws; lights use the simulation's exact phases.
  const signalPoles=[],signalArms=[],signalHeads=[],signalPoints=[];this.signalMeta=[];
  for(let x=min;x<=max;x+=spacing)for(let z=min;z<=max;z+=spacing){if(Math.abs(x)>450&&Math.abs(z)>450)continue;for(const sign of [-1,1])for(const horizontal of [false,true]){const px=x+sign*20,pz=z+sign*(horizontal?20:-20);signalPoles.push({p:[px,4,pz],s:[.2,8,.2]});signalArms.push({p:[px-(horizontal?0:sign*3.4),8,pz-(horizontal?sign*3.4:0)],s:horizontal?[.2,.2,7]:[7,.2,.2]});signalHeads.push({p:[px-(horizontal?0:sign*6.2),7.7,pz-(horizontal?sign*6.2:0)],s:horizontal?[.5,1.7,.65]:[.65,1.7,.5]});signalPoints.push({p:[px-(horizontal?-sign*.3:sign*6.2),7.35,pz-(horizontal?sign*6.2:-sign*.3)],s:horizontal?[.08,.28,.28]:[.28,.28,.08]});this.signalMeta.push({x,z,axis:horizontal?'ew':'ns'});}}
  this.instanced(this.geo.box,this.mat.carbon,signalPoles);this.instanced(this.geo.box,this.mat.carbon,signalArms);this.instanced(this.geo.box,this.mat.carbon,signalHeads);this.signals=this.instanced(this.geo.box,lit(0xffffff),signalPoints);this.lastSignalUpdate=-1;
  // Distant expressway silhouettes frame the city instead of an empty horizon.
  const highway=standard(0x243447,.7,.2);for(const z of [-670,670]){this.box(highway,[1500,2.3,26],[0,16,z]);for(let x=-600;x<=600;x+=150)this.box(highway,[5,16,8],[x,8,z]);this.box(this.mat.cyan,[1500,.15,.15],[0,18,z-12]);}
 }
 makeSign(text,hex){const canvas=document.createElement('canvas');canvas.width=512;canvas.height=128;const ctx=canvas.getContext('2d');ctx.fillStyle='#081522';ctx.fillRect(0,0,512,128);ctx.strokeStyle=`#${hex.toString(16)}`;ctx.lineWidth=6;ctx.strokeRect(4,4,504,120);ctx.fillStyle=`#${hex.toString(16)}`;ctx.font='bold 52px Arial';ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText(text,256,67);const texture=new THREE.CanvasTexture(canvas);texture.colorSpace=THREE.SRGBColorSpace;const material=new THREE.MeshBasicMaterial({map:texture,toneMapped:false});this.disposables.push(texture,material);return this.mesh(this.geo.plane,material);}
 carTemplate(type,bodyColor){
  const key=`${type}:${bodyColor}`;if(this.templates.has(key))return this.templates.get(key);
  const group=new THREE.Group(),bodyMat=new THREE.MeshPhysicalMaterial({color:bodyColor,roughness:.28,metalness:.18,clearcoat:1,clearcoatRoughness:.14}),isPolice=type==='police';
  const chassis=loft([{z:-3.05,w:1.04,b:.38,h:.7},{z:-1.5,w:1.22,b:.3,h:.98},{z:1.6,w:1.22,b:.3,h:1.04},{z:3,w:1.1,b:.45,h:1.12}]);this.mesh(chassis,bodyMat,group);
  const cabin=loft([{z:-1.05,w:.9,b:1,h:1.05},{z:-.18,w:.91,b:1,h:1.55},{z:1,w:.86,b:1,h:1.5},{z:1.65,w:.86,b:1,h:1.07}]);this.mesh(cabin,this.mat.glass,group);
  const roof=this.box(isPolice?standard(0xf4f7fa,.35,.3):bodyMat,[1.55,.09,1.15],[0,1.54,.45],group);
  const details=[],front=[],rear=[],tires=[],rims=[],panel=[];
  function part(list,geo,pos,scale,rotation=null){const g=geo.clone();const m=new THREE.Matrix4();const q=new THREE.Quaternion();if(rotation)q.setFromEuler(new THREE.Euler(...rotation));m.compose(new THREE.Vector3(...pos),q,new THREE.Vector3(...scale));g.applyMatrix4(m);list.push(g);}
  part(details,this.geo.box,[0,.42,-3.1],[2.15,.3,.12]);part(details,this.geo.box,[0,.45,3.04],[2.05,.25,.13]);part(details,this.geo.box,[0,.7,-3.15],[1.1,.22,.08]);
  part(details,this.geo.box,[-1.2,.5,0],[.18,.15,4.4]);part(details,this.geo.box,[1.2,.5,0],[.18,.15,4.4]);
  for(const x of [-.76,.76]){part(front,this.geo.box,[x,.84,-3.04],[.65,.075,.08]);part(rear,this.geo.box,[x,.91,3.01],[.7,.08,.08]);}
  const tireGeo=new THREE.CylinderGeometry(.51,.51,.35,14);const rimGeo=new THREE.CylinderGeometry(.30,.30,.37,10);
  for(const x of [-1.19,1.19])for(const z of [-1.9,1.95]){part(tires,tireGeo,[x,.52,z],[1,1,1],[0,0,Math.PI/2]);part(rims,rimGeo,[x,.52,z],[1,1,1],[0,0,Math.PI/2]);}
  tireGeo.dispose();rimGeo.dispose();
  for(const [parts,material]of [[details,this.mat.carbon],[front,this.mat.white],[rear,this.mat.red],[tires,this.mat.rubber],[rims,this.mat.chrome]]){const geo=mergeGeometries(parts);parts.forEach(g=>g.dispose());this.mesh(geo,material,group);}
  if(type==='player'){this.box(this.mat.carbon,[2.7,.12,.52],[0,1.55,2.67],group);for(const x of [-.82,.82])this.box(this.mat.carbon,[.1,.5,.18],[x,1.3,2.65],group);this.box(this.mat.carbon,[.42,.035,1.1],[0,1.06,-2.1],group);}
  if(isPolice){this.box(this.mat.carbon,[1.85,.1,.5],[0,1.66,.4],group);const red=this.box(this.mat.red,[.75,.16,.45],[-.48,1.78,.4],group);red.name='police-red';const blue=this.box(this.mat.blue,[.75,.16,.45],[.48,1.78,.4],group);blue.name='police-blue';this.box(standard(0xe6edf2,.4,.3),[2.46,.43,1.2],[0,.88,.5],group);}
  const shadow=this.mesh(this.geo.shadow??=new THREE.PlaneGeometry(3.5,7),this.shadowMaterial(),group);shadow.rotation.x=-Math.PI/2;shadow.position.y=.018;
  this.templates.set(key,group);return group;
 }
 shadowMaterial(){if(this.mat.shadow)return this.mat.shadow;const c=document.createElement('canvas');c.width=128;c.height=256;const ctx=c.getContext('2d');ctx.save();ctx.scale(1,2);const gradient=ctx.createRadialGradient(64,64,8,64,64,64);gradient.addColorStop(0,'rgba(255,255,255,0.8)');gradient.addColorStop(.4,'rgba(255,255,255,0.65)');gradient.addColorStop(1,'rgba(255,255,255,0)');ctx.fillStyle=gradient;ctx.fillRect(0,0,128,128);ctx.restore();const map=new THREE.CanvasTexture(c);this.disposables.push(map);return this.mat.shadow=new THREE.MeshBasicMaterial({color:0x02050b,map,transparent:true,opacity:.6,depthWrite:false,polygonOffset:true,polygonOffsetFactor:-1,polygonOffsetUnits:-1});}
 makeCar(type,color){const car=this.carTemplate(type,color).clone(true);car.scale.x=1.12;if(type==='player'){
   const flameGeometry=this.geo.flame??=new THREE.ConeGeometry(.19,1.65,8),flameMaterial=this.mat.flame??=lit(0x55dfff);const flames=new THREE.Group();for(const x of [-.72,.72]){const f=this.mesh(flameGeometry,flameMaterial,flames);f.position.set(x,.5,3.65);f.rotation.x=Math.PI/2;}flames.name='nitro-flames';flames.visible=false;car.add(flames);
   const under=this.mesh(this.geo.under??=new THREE.PlaneGeometry(3.5,7),this.mat.under??=new THREE.MeshBasicMaterial({color:0xff6025,map:this.shadowMaterial().map,transparent:true,opacity:.05,depthWrite:false}),car);under.rotation.x=-Math.PI/2;under.position.y=.024;
  }return car;
 }
 setVehicle(id){if(this.vehicle===id&&this.player)return;this.vehicle=id;const old=this.player;this.player=this.makeCar('player',id==='velocity'?0x26c9d5:id==='enforcer'?0xff496e:0xe95528);this.player.scale.set(id==='enforcer'?1.25:id==='velocity'?1.04:1.12,1,id==='enforcer'?1.08:1);if(old){this.player.position.copy(old.position);this.scene.remove(old);}this.scene.add(this.player);}
 makeCheckpoint(){const group=new THREE.Group();const ring=this.mesh(new THREE.TorusGeometry(22,.3,6,96),this.mat.cyan,group);ring.rotation.x=Math.PI/2;ring.position.y=.15;const poleMat=new THREE.MeshBasicMaterial({color:0x4ce4ff,transparent:true,opacity:.13,depthWrite:false,side:THREE.DoubleSide});const beam=this.mesh(new THREE.CylinderGeometry(2,2,95,16,1,true),poleMat,group);beam.position.y=47;const icon=this.mesh(new THREE.OctahedronGeometry(2.4),this.mat.cyan,group);icon.position.y=14;group.userData.icon=icon;return group;}
 impact(x,z,strength=1){this.shake=Math.min(1.5,this.shake+strength*.7);for(let i=0;i<Math.round(18*strength)&&this.particles.length<180;i++){const a=Math.random()*TAU,s=6+Math.random()*12;this.particles.push({x,y:.8,z,vx:Math.cos(a)*s,vy:2+Math.random()*5,vz:Math.sin(a)*s,life:.35+Math.random()*.4});}}
 syncEntities(sim,menu){
  const active=new Set(),car=sim.car;const lists=[...(sim.traffic||[]).map(e=>({...e,type:'traffic'})),...(sim.police||[]).map(e=>({...e,type:'police'})),...(sim.roadblocks||[]).flatMap(b=>(b.cars||[]).map(e=>({...e,type:'police'})))];
  if(menu&&!lists.length)lists.push({id:'demo1',x:8,z:-10,heading:Math.PI,speed:0,type:'traffic',color:0x7894a7},{id:'demo2',x:-8,z:-100,heading:0,speed:0,type:'traffic',color:0xe4b563});
  for(const e of lists){const key=`${e.type}:${e.id}`;active.add(key);let obj=this.entities.get(key);if(!obj){const index=typeof e.color==='number'?Math.abs(Math.round(e.color))%PALETTE.length:Math.abs(String(e.id).split('').reduce((a,c)=>a+c.charCodeAt(0),0))%PALETTE.length;obj=this.makeCar(e.type,e.type==='police'?0x132330:PALETTE[index]);this.entities.set(key,obj);this.scene.add(obj);}obj.position.set(e.x,0,e.z);obj.rotation.y=-(e.heading||0);obj.visible=Math.hypot(e.x-car.x,e.z-car.z)<430;const red=obj.getObjectByName('police-red'),blue=obj.getObjectByName('police-blue');if(red){const flash=Math.sin(this.time*23+(Number(e.id)||0));red.visible=flash>.05;blue.visible=flash<-.05;}}
  for(const [key,obj]of this.entities)if(!active.has(key)){this.scene.remove(obj);this.entities.delete(key);}
  const roadblocks=sim.roadblocks||[],activeBlocks=new Set();for(const b of roadblocks){const id=b.id??`${b.x},${b.z}`;activeBlocks.add(id);let object=this.barriers.get(id);if(!object){object=new THREE.Group();for(const side of [-1,1]){const p=b.axis==='x'?[0,.3,side*14]:[side*14,.3,0];const cone=this.mesh(this.geo.flare??=new THREE.ConeGeometry(.45,.9,6),this.mat.orange,object);cone.position.set(...p);}this.scene.add(object);this.barriers.set(id,object);}object.position.set(b.x,0,b.z);object.visible=b.active!==false;}for(const [id,obj]of this.barriers)if(!activeBlocks.has(id)){this.scene.remove(obj);this.barriers.delete(id);}

 }
 setQuality(value){this.quality=value;this.resize();}
 resize(){const ratio=this.quality==='ultra'?Math.min(devicePixelRatio,1.7):this.quality==='performance'?.7:Math.min(devicePixelRatio,1.15);this.renderer.setPixelRatio(ratio);this.renderer.setSize(innerWidth,innerHeight);this.composer.setPixelRatio(ratio);this.composer.setSize(innerWidth,innerHeight);this.bloom.enabled=this.quality!=='performance';this.camera.aspect=innerWidth/innerHeight;this.camera.updateProjectionMatrix();}
 render(dt,sim,{menu=false,lookBack=false,camera='chase'}={}){
  if(this.disposed)return;dt=Math.min(dt,.12);this.time+=dt;const car=sim.car||{x:0,z:75,heading:0,speed:0},heading=car.heading||0,speed=Math.abs(car.speed||0),forward=new THREE.Vector3(Math.sin(heading),0,-Math.cos(heading));
  this.player.position.set(car.x,.03+Math.sin(this.time*45)*Math.min(.025,speed*.0003),car.z);const steering=sim.input?.steer??car.steer??0;this.player.rotation.set(0,-heading,-steering*Math.min(.035,speed*.0005));
  const boost=!!(car.boosting||sim.boosting||car.nitroActive);const flames=this.player.getObjectByName('nitro-flames');flames.visible=boost;flames.scale.z=.7+Math.random()*.7;
  this.syncEntities(sim,menu);if(Math.abs((sim.time||this.time)-this.lastSignalUpdate)>.2){const now=sim.time||this.time;this.lastSignalUpdate=now;for(let i=0;i<this.signalMeta.length;i++){const p=this.signalMeta[i],green=trafficLightAt(p.x,p.z,now)===p.axis;this.signals.setColorAt(i,new THREE.Color(green?0x73ffa7:0xff3c4a));}if(this.signals.instanceColor)this.signals.instanceColor.needsUpdate=true;}this.road.material.uniforms.player.value.set(car.x,car.z);this.road.material.uniforms.direction.value.set(forward.x,forward.z);this.road.material.uniforms.time.value=this.time;
  if(sim.checkpoint){this.checkpoint.visible=!menu&&sim.state!=='over';this.checkpoint.position.set(sim.checkpoint.x,0,sim.checkpoint.z);this.checkpoint.userData.icon.rotation.y=this.time;this.checkpoint.userData.icon.position.y=13+Math.sin(this.time*2);}
  else this.checkpoint.visible=false;
  let desired,target;if(menu){const a=.72+Math.sin(this.time*.08)*.08;desired=new THREE.Vector3(car.x+Math.sin(a)*15,5.1,car.z+Math.cos(a)*15);target=new THREE.Vector3(car.x-4.4,1.1,car.z-2);}
  else{const dist=(camera==='wide'||camera==='far')?18:camera==='low'?11:13.5,height=(camera==='wide'||camera==='far')?7:camera==='low'?3.5:4.7;desired=new THREE.Vector3(car.x,0,car.z).addScaledVector(forward,lookBack?dist:-dist);desired.y=height+Math.min(1.1,speed*.008);target=new THREE.Vector3(car.x,1.5,car.z).addScaledVector(forward,lookBack?-13:16+speed*.045);
   if(this.buildings.some(b=>Math.abs(desired.x-b.x)<b.w+1&&Math.abs(desired.z-b.z)<b.d+1)){desired.set(car.x,7,car.z).addScaledVector(forward,lookBack?5:-5);}
  }
  if(!this.cameraInitialized){this.camera.position.copy(desired);this.cameraTarget.copy(target);this.cameraInitialized=true;}
  else{this.camera.position.lerp(desired,smooth(menu?2.5:8,dt));this.cameraTarget.lerp(target,smooth(menu?2.5:9,dt));}
  this.shake=Math.max(0,this.shake-dt*2);if(this.motion&&!menu){const bump=(boost?.025:0)+this.shake*.18;this.camera.position.x+=(Math.random()-.5)*bump;this.camera.position.y+=(Math.random()-.5)*bump;}
  const fov=menu?53:64+Math.min(15,speed*.1)+(boost?7:0);this.camera.fov=THREE.MathUtils.lerp(this.camera.fov,fov,smooth(4,dt));this.camera.updateProjectionMatrix();this.camera.lookAt(this.cameraTarget);this.sky.position.copy(this.camera.position);
  for(let i=this.particles.length-1;i>=0;i--){const p=this.particles[i];p.life-=dt;if(p.life<=0){this.particles.splice(i,1);continue;}p.x+=p.vx*dt;p.y+=p.vy*dt;p.z+=p.vz*dt;p.vy-=dt*18;}
  for(let i=0;i<this.particles.length;i++){const p=this.particles[i];dummy.position.set(p.x,Math.max(.05,p.y),p.z);dummy.rotation.set(p.life*10,p.life*7,0);dummy.scale.setScalar(p.life*.2);dummy.updateMatrix();this.particleMesh.setMatrixAt(i,dummy.matrix);}this.particleMesh.count=this.particles.length;this.particleMesh.instanceMatrix.needsUpdate=true;
  const drifting=!!(car.drifting||sim.drifting)||Math.abs(car.slip||0)>.2;if(drifting&&!menu&&speed>12){const side=new THREE.Vector3(Math.cos(heading),0,Math.sin(heading));const wheels=[new THREE.Vector3(car.x,.015,car.z).addScaledVector(forward,-1.9).addScaledVector(side,-1.1),new THREE.Vector3(car.x,.015,car.z).addScaledVector(forward,-1.9).addScaledVector(side,1.1)];if(this.previousWheel){for(let n=0;n<2;n++){const j=this.trailIndex*6;this.trailPositions.set([...this.previousWheel[n].toArray(),...wheels[n].toArray()],j);this.trailIndex=(this.trailIndex+1)%600;this.trailCount=Math.min(600,this.trailCount+1);}}this.previousWheel=wheels;this.trailGeometry.attributes.position.needsUpdate=true;this.trailGeometry.setDrawRange(0,this.trailCount*2);}else this.previousWheel=null;
  if(this.bloom.enabled)this.composer.render(dt);else this.renderer.render(this.scene,this.camera);
 }
 dispose(){this.disposed=true;const geometries=new Set(),materials=new Set();this.scene.traverse(o=>{if(o.geometry)geometries.add(o.geometry);if(o.material){for(const m of Array.isArray(o.material)?o.material:[o.material])materials.add(m);}});for(const t of this.templates.values())t.traverse(o=>{if(o.geometry)geometries.add(o.geometry);if(o.material)materials.add(o.material);});geometries.forEach(g=>g.dispose());materials.forEach(m=>m.dispose());this.disposables.forEach(o=>o.dispose());this.composer.dispose();this.renderer.dispose();}
}
