// MIDNIGHT RUN: deterministic arcade driving and road-aware pursuit simulation.
// Coordinates: +X east, +Z south. Heading 0 faces -Z, PI/2 faces +X.
export const CITY=Object.freeze({spacing:150,roadHalf:18,half:690,blocks:8,gridMin:-600,gridMax:600,lane:6.5});
export const VEHICLES=Object.freeze({
  interceptor:{name:'APEX GT',tag:'ÉQUILIBRÉ',maxSpeed:104,boostSpeed:144,acceleration:44,health:100,color:0xffb13d,handling:1},
  velocity:{name:'VOLT R',tag:'HYPERVITESSE',maxSpeed:118,boostSpeed:166,acceleration:48,health:78,color:0x5beaff,handling:.95},
  enforcer:{name:'BRUTE V8',tag:'RÉSISTANCE',maxSpeed:98,boostSpeed:135,acceleration:39,health:145,color:0xff496e,handling:.92}
});
const PI=Math.PI,TAU=PI*2,clamp=(x,a,b)=>Math.max(a,Math.min(b,x));
const distance=(a,b)=>Math.hypot(a.x-b.x,a.z-b.z);
const angleDelta=(a,b)=>Math.atan2(Math.sin(a-b),Math.cos(a-b));
const headingTo=(x,z)=>Math.atan2(x,-z);
const grid=v=>clamp(Math.round(v/CITY.spacing)*CITY.spacing,CITY.gridMin,CITY.gridMax);
const key=n=>`${n.x},${n.z}`;
const sameNode=(a,b)=>a.x===b.x&&a.z===b.z;
export function seededRandom(seed){return ()=>{seed|=0;seed=seed+0x6D2B79F5|0;let t=Math.imul(seed^seed>>>15,1|seed);t=t+Math.imul(t^t>>>7,61|t)^t;return ((t^t>>>14)>>>0)/4294967296;};}
export function onRoad(x,z,margin=0){return Math.abs(x)<=CITY.half-10&&Math.abs(z)<=CITY.half-10&&(Math.abs(x-grid(x))<=CITY.roadHalf-margin||Math.abs(z-grid(z))<=CITY.roadHalf-margin);}
export function trafficLightAt(x,z,time){const phase=((time+(grid(x)/150+grid(z)/150)*1.4)%17+17)%17;return phase<7.5?'ns':phase<8.5?'all-red':phase<16?'ew':'all-red';}
export function routeBetween(start,goal){
  start={x:grid(start.x),z:grid(start.z)};goal={x:grid(goal.x),z:grid(goal.z)};
  const open=[start],came=new Map(),cost=new Map([[key(start),0]]),goalKey=key(goal);
  while(open.length){let best=0;for(let i=1;i<open.length;i++){const a=open[i],b=open[best];if(cost.get(key(a))+Math.abs(a.x-goal.x)+Math.abs(a.z-goal.z)<cost.get(key(b))+Math.abs(b.x-goal.x)+Math.abs(b.z-goal.z))best=i;}
    const node=open.splice(best,1)[0],nodeKey=key(node);if(nodeKey===goalKey){const path=[node];while(came.has(key(path[0])))path.unshift(came.get(key(path[0])));return path;}
    for(const [dx,dz]of [[150,0],[-150,0],[0,150],[0,-150]]){const n={x:node.x+dx,z:node.z+dz};if(Math.abs(n.x)>600||Math.abs(n.z)>600)continue;const k=key(n),newCost=cost.get(nodeKey)+150;if(newCost<(cost.get(k)??Infinity)){came.set(k,node);cost.set(k,newCost);if(!open.some(v=>key(v)===k))open.push(n);}}
  }return [start];
}
function pointSegmentSquared(p,a,b){const x=b.x-a.x,z=b.z-a.z,den=x*x+z*z,t=den?clamp(((p.x-a.x)*x+(p.z-a.z)*z)/den,0,1):0;return (p.x-a.x-t*x)**2+(p.z-a.z-t*z)**2;}
function capsuleSegment(c){const x=Math.sin(c.heading)*2.1,z=-Math.cos(c.heading)*2.1;return [{x:c.x-x,z:c.z-z},{x:c.x+x,z:c.z+z}];}
function capsulesHit(a,b){
  if(distance(a,b)>8.4)return false;const [p,q]=capsuleSegment(a),[r,s]=capsuleSegment(b);
  const cross=(a,b,c)=>(b.x-a.x)*(c.z-a.z)-(b.z-a.z)*(c.x-a.x);
  if(cross(p,q,r)*cross(p,q,s)<0&&cross(r,s,p)*cross(r,s,q)<0)return true;
  return Math.min(pointSegmentSquared(p,r,s),pointSegmentSquared(q,r,s),pointSegmentSquared(r,p,q),pointSegmentSquared(s,p,q))<3.65**2;
}
function forwardNode(npc){
  if(Math.abs(Math.sin(npc.heading))>.7)return {x:clamp((Math.sin(npc.heading)>0?Math.ceil(npc.x/150):Math.floor(npc.x/150))*150,-600,600),z:grid(npc.z)};
  return {x:grid(npc.x),z:clamp((Math.cos(npc.heading)>0?Math.floor(npc.z/150):Math.ceil(npc.z/150))*150,-600,600)};
}
function nearestRoad(pos,margin=3){const x=grid(pos.x),z=grid(pos.z),limit=CITY.roadHalf-margin;return Math.abs(pos.x-x)<Math.abs(pos.z-z)?{x:clamp(pos.x,x-limit,x+limit),z:clamp(pos.z,-674,674)}:{x:clamp(pos.x,-674,674),z:clamp(pos.z,z-limit,z+limit)};}
function visible(a,b){const d=distance(a,b);if(d>185)return false;for(let n=1;n<Math.ceil(d/12);n++){const t=n/Math.ceil(d/12);if(!onRoad(a.x+(b.x-a.x)*t,a.z+(b.z-a.z)*t))return false;}return true;}
export class Simulation{
  constructor({onEvent=()=>{}}={}){this.onEvent=onEvent;this.id=0;this.reset('interceptor',1240);this.state='menu';}
  emit(type,data={}){this.onEvent({type,...data});}
  reset(vehicle,seed){
    this.vehicle=VEHICLES[vehicle]?vehicle:'interceptor';this.config=VEHICLES[this.vehicle];this.seed=seed>>>0;this.random=seededRandom(this.seed);this.time=0;this.score=0;this.distance=0;this.heat=18;this.wanted=1;this.busted=0;this.chaseLost=0;this.combo=1;this.comboTime=0;this.checkpoints=0;this.checkpointTime=45;this.recoveryCooldown=0;this.collisionCooldown=0;this.policeSpawnTime=0;this.roadblockTime=16;this.escapeCooldown=0;this.driftAccumulator=0;this.id=0;
    this.car={x:6.5,z:75,heading:0,speed:0,vx:0,vz:0,health:this.config.health,maxHealth:this.config.health,nitro:100,boosting:false,drifting:false,gear:1,rpm:0,steer:0};
    this.stats={topSpeed:0,maxSpeed:0,nearMisses:0,driftScore:0,collisions:0,escapes:0};this.traffic=[];this.police=[];this.roadblocks=[];this.checkpoint={x:0,z:-450};
    this.populateTraffic();this.spawnPolice(true);this.spawnPolice(true);
  }
  start(vehicle='interceptor',seed=Date.now()>>>0){this.reset(vehicle,seed);this.state='play';this.emit('start',{vehicle:this.vehicle,seed:this.seed});this.emit('toast',{title:'LA VILLE EST À VOUS',subtitle:'Traversez les balises · Shift : nitro · Espace : drift'});}
  pause(){if(this.state==='play'){this.state='pause';this.car.boosting=false;this.emit('pause');}else if(this.state==='pause'){this.state='play';this.emit('resume');}}
  recover(){
    if(this.state!=='play'||this.recoveryCooldown>0)return false;const c=this.car,x=grid(c.x),z=grid(c.z);if(Math.abs(c.x-x)<=Math.abs(c.z-z)){c.x=x+(Math.cos(c.heading)>=0?6.5:-6.5);c.z=clamp(c.z,-640,640);c.heading=Math.cos(c.heading)>=0?0:PI;}else{c.z=z+(Math.sin(c.heading)>=0?6.5:-6.5);c.x=clamp(c.x,-640,640);c.heading=Math.sin(c.heading)>=0?PI/2:-PI/2;}
    c.speed=c.vx=c.vz=0;c.health=Math.max(5,c.health-5);c.nitro=Math.max(0,c.nitro-10);this.score=Math.max(0,this.score-150);this.busted=Math.max(0,this.busted-.25);this.collisionCooldown=2;this.recoveryCooldown=3;this.emit('toast',{title:'REMIS SUR LA ROUTE',subtitle:'−150 points · −5 intégrité'});return true;
  }
  finish(reason){if(this.state!=='play')return;this.state='over';this.car.boosting=false;this.emit('result',{reason,score:Math.floor(this.score),time:this.time,distance:this.distance,checkpoints:this.checkpoints,maxSpeed:this.stats.maxSpeed,nearMisses:this.stats.nearMisses,driftScore:Math.floor(this.stats.driftScore),seed:this.seed,vehicle:this.vehicle,escapes:this.stats.escapes});}
  populateTraffic(){
    const palette=[0xdad9d2,0x709ab1,0xc26350,0x55696b,0xe4bb62,0x7a6fa5,0x8c949c];
    const add=(x,z,heading)=>{if(distance({x,z},this.car)<30||this.traffic.some(v=>distance(v,{x,z})<16))return;this.traffic.push({id:++this.id,x,z,heading,speed:15+this.random()*10,maxSpeed:18+this.random()*12,color:palette[Math.floor(this.random()*palette.length)],path:[],nextRoute:0,nearMissTime:0,hitTime:0,kind:this.random()<.2?'van':'sedan',braking:false});};
    // A visible stream ahead at the start, with enough space to accelerate.
    for(let n=0;n<10;n++)add(n%2?6.5:-6.5,-25-n*52,n%2?0:PI);
    for(let attempts=0;this.traffic.length<68&&attempts<1000;attempts++){const horizontal=this.random()<.5,line=(Math.floor(this.random()*9)-4)*150,along=(this.random()-.5)*1260,direction=this.random()<.5?1:-1;const heading=horizontal?(direction>0?PI/2:-PI/2):(direction>0?0:PI);add(horizontal?along:line+Math.cos(heading)*6.5,horizontal?line+Math.sin(heading)*6.5:along,heading);}
  }
  spawnPolice(initial=false){
    if(this.police.length>=9)return false;let pos=null,heading=0;
    for(let i=0;i<60;i++){const line=(Math.floor(this.random()*9)-4)*150,along=(this.random()-.5)*1150,horizontal=this.random()<.5;const p={x:horizontal?along:line+6.5,z:horizontal?line+6.5:along};const d=distance(p,this.car);if(d>(initial?160:205)&&d<(initial?430:510)&&!this.traffic.some(t=>distance(t,p)<12)&&!this.police.some(t=>distance(t,p)<18)){pos=p;heading=horizontal?PI/2:0;break;}}
    if(!pos)return false;const role=['hunter','interceptor','rammer'][this.police.length%3];this.police.push({id:++this.id,...pos,heading,speed:initial?28:45,maxSpeed:role==='rammer'?112:104,role,color:0x1d2935,path:[],nextRoute:0,hitTime:0,age:0,stuck:0,lastX:pos.x,lastZ:pos.z,braking:false});return true;
  }
  randomTrafficPath(npc){const here=forwardNode(npc),neighbors=[];for(const[dx,dz]of[[150,0],[-150,0],[0,150],[0,-150]]){const n={x:here.x+dx,z:here.z+dz};if(Math.abs(n.x)>600||Math.abs(n.z)>600)continue;const h=headingTo(dx,dz);if(Math.abs(angleDelta(h,npc.heading))<2.5)neighbors.push(n);}if(!neighbors.length)neighbors.push({x:clamp(here.x-Math.sin(npc.heading)*150,-600,600),z:clamp(here.z+Math.cos(npc.heading)*150,-600,600)});const next=neighbors[Math.floor(this.random()*neighbors.length)];npc.path=distance(npc,here)<20?[next]:[here,next];}
  policePath(npc){
    const c=this.car,horizon=npc.role==='interceptor'?clamp(distance(npc,c)/65,1.4,4):npc.role==='rammer'?.8:.4;
    const target={x:clamp(c.x+c.vx*horizon,-600,600),z:clamp(c.z+c.vz*horizon,-600,600)};
    // Interceptors occupy the next junction rather than blindly following the tail.
    if(npc.role==='interceptor'&&Math.abs(c.speed)>25){if(Math.abs(c.vx)>Math.abs(c.vz)){target.x=clamp((c.vx>0?Math.ceil(target.x/150):Math.floor(target.x/150))*150,-600,600);target.z=grid(c.z);}else{target.x=grid(c.x);target.z=clamp((c.vz>0?Math.ceil(target.z/150):Math.floor(target.z/150))*150,-600,600);}}
    const first=forwardNode(npc),route=routeBetween(first,target);if(route.length===1&&distance(npc,first)<15){const last={x:grid(c.x),z:grid(c.z)};route.push(last);}npc.path=route;npc.nextRoute=this.time+.65+this.random()*.35;
  }
  updateNpc(npc,dt,isPolice){
    npc.braking=false;
    if(isPolice&&(this.time>=npc.nextRoute||!npc.path.length))this.policePath(npc);else if(!isPolice&&!npc.path.length)this.randomTrafficPath(npc);
    let node=npc.path[0];if(!node)return;
    if(distance(npc,node)<14&&npc.path.length>1){npc.path.shift();node=npc.path[0];}
    else if(distance(npc,node)<12&&npc.path.length===1){if(isPolice){npc.nextRoute=0;this.policePath(npc);}else this.randomTrafficPath(npc);node=npc.path[0];}
    let desiredHeading=headingTo(node.x-npc.x,node.z-npc.z);const lane=isPolice&&distance(npc,this.car)<70?2.5:6.5;
    let tx=node.x+Math.cos(desiredHeading)*lane,tz=node.z+Math.sin(desiredHeading)*lane;
    if(isPolice&&distance(npc,this.car)<85&&visible(npc,this.car)&&this.wanted>0){const horizon=npc.role==='rammer'?.35:.2;tx=this.car.x+this.car.vx*horizon;tz=this.car.z+this.car.vz*horizon;}
    desiredHeading=headingTo(tx-npc.x,tz-npc.z);const turn=angleDelta(desiredHeading,npc.heading),turnFactor=clamp(1-Math.abs(turn)/2,.24,1);let desiredSpeed=(isPolice?npc.maxSpeed:Math.min(npc.maxSpeed,28))*turnFactor;
    const nodeDistance=distance(npc,node);if(npc.path.length>1){const next=npc.path[1],outgoing=headingTo(next.x-node.x,next.z-node.z);if(Math.abs(angleDelta(outgoing,npc.heading))>.5){const cornerSpeed=isPolice?23:16,brakeDistance=Math.max(0,nodeDistance-15);desiredSpeed=Math.min(desiredSpeed,Math.sqrt(cornerSpeed*cornerSpeed+2*(isPolice?43:14)*brakeDistance));}}if(!isPolice&&nodeDistance<27&&nodeDistance>12){const vertical=Math.abs(Math.cos(npc.heading))>.7,light=trafficLightAt(node.x,node.z,this.time);if(light==='all-red'||(vertical&&light!=='ns')||(!vertical&&light!=='ew')){desiredSpeed=Math.min(desiredSpeed,Math.max(0,(nodeDistance-14)*1.4));npc.braking=true;}}
    if(isPolice&&this.wanted===0)desiredSpeed=Math.min(desiredSpeed,28);
    // Local traffic avoidance and car following; police may use the opposing lane.
    const fx=Math.sin(npc.heading),fz=-Math.cos(npc.heading),rx=Math.cos(npc.heading),rz=Math.sin(npc.heading);let avoid=0;
    for(const other of this.traffic){if(other===npc)continue;const dx=other.x-npc.x,dz=other.z-npc.z,along=dx*fx+dz*fz,side=dx*rx+dz*rz;if(along>0&&along<(isPolice?33:19)&&Math.abs(side)<4.5&&(isPolice||Math.abs(angleDelta(other.heading,npc.heading))<.75)){if(isPolice){avoid=side>=0?-.35:.35;desiredSpeed=Math.min(desiredSpeed,Math.max(other.speed+15,35));}else{desiredSpeed=Math.min(desiredSpeed,Math.max(0,(along-9)*2));npc.braking=true;}}}
    npc.heading+=clamp(turn+avoid,-(isPolice?2.8:2.2)*dt,(isPolice?2.8:2.2)*dt);const accel=isPolice?34:12;npc.speed+=clamp(desiredSpeed-npc.speed,-accel*1.6*dt,accel*dt);
    npc.x+=Math.sin(npc.heading)*npc.speed*dt;npc.z-=Math.cos(npc.heading)*npc.speed*dt;
    if(!onRoad(npc.x,npc.z,2)){const p=nearestRoad(npc,2);npc.x=p.x;npc.z=p.z;npc.speed*=Math.exp(-dt*2);}
    npc.x=clamp(npc.x,-667,667);npc.z=clamp(npc.z,-667,667);
    if(isPolice){npc.age+=dt;if(distance(npc,{x:npc.lastX,z:npc.lastZ})<.1&&npc.speed<5)npc.stuck+=dt;else npc.stuck=Math.max(0,npc.stuck-dt*.6);npc.lastX=npc.x;npc.lastZ=npc.z;if(npc.stuck>2){npc.nextRoute=0;npc.heading+=dt*1.8;npc.speed=14;npc.stuck=1.5;}}
  }
  wallCollision(previous){
    const c=this.car,limit=CITY.roadHalf-2.3,x=grid(c.x),z=grid(c.z),dx=Math.abs(c.x-x),dz=Math.abs(c.z-z);let normalX=0,normalZ=0;
    if(Math.abs(c.x)>674){normalX=c.x>0?-1:1;c.x=clamp(c.x,-674,674);}if(Math.abs(c.z)>674){normalZ=c.z>0?-1:1;c.z=clamp(c.z,-674,674);}
    if(dx>limit&&dz>limit){const wasVertical=Math.abs(previous.x-grid(previous.x))<=limit,wasHorizontal=Math.abs(previous.z-grid(previous.z))<=limit;if(wasVertical&&!wasHorizontal||!wasHorizontal&&dx<dz||wasVertical&&wasHorizontal&&dx-limit<dz-limit){normalX=c.x>x?-1:1;c.x=x+Math.sign(c.x-x)*limit;}else{normalZ=c.z>z?-1:1;c.z=z+Math.sign(c.z-z)*limit;}}
    if(normalX||normalZ){const impact=Math.abs(c.vx*normalX+c.vz*normalZ);if(normalX)c.vx=-c.vx*.15;if(normalZ)c.vz=-c.vz*.15;c.speed*=.72;this.damage(clamp(impact*.14,1,18),'wall',impact/100);return true;}return false;
  }
  damage(amount,kind,strength=.5){if(this.collisionCooldown>0||this.state!=='play')return;const resistance=this.vehicle==='enforcer'?.67:1;this.car.health=Math.max(0,this.car.health-amount*resistance);this.stats.collisions++;this.collisionCooldown=.65;this.combo=1;this.comboTime=0;this.heat=clamp(this.heat+3,0,120);this.emit('collision',{x:this.car.x,z:this.car.z,kind,strength:clamp(strength,0,1)});if(this.car.health<=0)this.finish('destroyed');}
  addStyle(amount,kind){this.comboTime=4;this.score+=amount*this.combo;this.combo=clamp(this.combo+.2,1,5);if(kind==='near-miss'){this.stats.nearMisses++;this.car.nitro=clamp(this.car.nitro+7,0,100);this.heat=clamp(this.heat+1.5,0,120);this.emit('near-miss',{x:this.car.x,z:this.car.z,bonus:Math.round(amount*this.combo)});}}
  collideNpc(npc,isPolice){
    const c=this.car,d=distance(c,npc);if(d>10)return;
    if(capsulesHit(c,npc)){
      const dx=c.x-npc.x,dz=c.z-npc.z,den=Math.max(.1,Math.hypot(dx,dz)),nx=dx/den,nz=dz/den,relative=Math.abs((c.vx-Math.sin(npc.heading)*npc.speed)*nx+(c.vz+Math.cos(npc.heading)*npc.speed)*nz);
      c.x+=nx*.6;c.z+=nz*.6;npc.x-=nx*.35;npc.z-=nz*.35;const impulse=Math.max(5,relative*.7);c.vx+=nx*impulse;c.vz+=nz*impulse;c.vx*=.75;c.vz*=.75;npc.speed*=.82;
      if(this.time-npc.hitTime>.6){this.damage(clamp(relative*.12+2,3,isPolice?12:18),isPolice?'police':'traffic',relative/90);npc.hitTime=this.time;}
    }else if(!isPolice&&d<8.3&&Math.abs(c.speed)>30&&this.time>npc.nearMissTime){npc.nearMissTime=this.time+8;this.addStyle(120,'near-miss');}
  }
  newRoadblock(){
    if(this.roadblocks.length>=2)return;const c=this.car,horizontal=Math.abs(c.vx)>Math.abs(c.vz),sign=horizontal?(c.vx>=0?1:-1):(c.vz>=0?1:-1),along=horizontal?c.x:c.z,node=clamp(Math.round((along+sign*250)/150)*150,-600,600),cross=grid(horizontal?c.z:c.x);
    const p={x:horizontal?node:cross,z:horizontal?cross:node};if(distance(c,p)<170)return;
    const heading=horizontal?0:PI/2,cars=[];for(const side of [-7,7])cars.push({x:p.x+(horizontal?0:side),z:p.z+(horizontal?side:0),heading,speed:0,hitTime:0,id:++this.id});this.roadblocks.push({id:++this.id,...p,heading,axis:horizontal?'x':'z',age:0,life:22,span:30,cars});this.emit('toast',{title:'BARRAGE SIGNALÉ',subtitle:'Changez de rue ou utilisez l’intersection pour esquiver'});
  }
  nextCheckpoint(){const previous=this.checkpoint;for(let i=0;i<100;i++){const p={x:(Math.floor(this.random()*9)-4)*150,z:(Math.floor(this.random()*9)-4)*150};const d=distance(p,this.car);if(d>300&&d<1000&&distance(p,previous)>200){this.checkpoint=p;this.checkpointTime=45;return;}}this.checkpoint={x:this.car.x>0?-450:450,z:this.car.z>0?-450:450};this.checkpointTime=50;}
  update(dt,input={}){
    if(this.state!=='play')return;dt=clamp(dt,0,.05);if(!dt)return;this.time+=dt;this.recoveryCooldown=Math.max(0,this.recoveryCooldown-dt);this.collisionCooldown=Math.max(0,this.collisionCooldown-dt);this.escapeCooldown=Math.max(0,this.escapeCooldown-dt);this.comboTime=Math.max(0,this.comboTime-dt);if(!this.comboTime)this.combo=1;
    const c=this.car,cfg=this.config,previous={x:c.x,z:c.z};const throttle=clamp(Number(input.throttle)||0,-1,1),steer=clamp(Number(input.steer)||0,-1,1),brake=!!input.brake||throttle<0,handbrake=!!input.handbrake;
    c.steer+=(steer-c.steer)*Math.min(1,dt*9);let speed=Math.hypot(c.vx,c.vz),forwardSpeed=c.vx*Math.sin(c.heading)-c.vz*Math.cos(c.heading);const speedFactor=clamp(speed/10,0,1);let turnRate=(2.7/(1+speed/65))*cfg.handling*(handbrake?1.7:1);c.heading+=c.steer*turnRate*speedFactor*(forwardSpeed>=0?1:-1)*dt;c.heading=angleDelta(c.heading,0);
    const fx=Math.sin(c.heading),fz=-Math.cos(c.heading),rx=Math.cos(c.heading),rz=Math.sin(c.heading);let long=c.vx*fx+c.vz*fz,lateral=c.vx*rx+c.vz*rz;
    c.boosting=!!input.nitro&&(c.boosting?c.nitro>0:c.nitro>=12)&&throttle>0&&!brake&&long>8;c.nitro=clamp(c.nitro+(c.boosting?-27:6.5)*dt,0,100);
    let acceleration=throttle>0&&!brake?cfg.acceleration:0;if(c.boosting)acceleration+=47;if(brake)acceleration=long>2?-78:long>-23?-18:0;
    if(!throttle&&!brake)acceleration=-Math.sign(long)*(4+Math.abs(long)*.065);else if(!brake)acceleration-=Math.max(0,long)*.055;
    if(handbrake){acceleration-=Math.sign(long)*17;lateral*=Math.exp(-dt*3.3);}else lateral*=Math.exp(-dt*10.5);
    const maxSpeed=c.boosting?cfg.boostSpeed:cfg.maxSpeed;const beforeLong=long;long+=acceleration*dt;if(long>maxSpeed)long=beforeLong<=maxSpeed?maxSpeed:Math.min(long,Math.max(maxSpeed,beforeLong-30*dt));long=clamp(long,-23,cfg.boostSpeed);if(Math.abs(long)<.15&&!throttle&&!brake)long=0;
    c.vx=fx*long+rx*lateral;c.vz=fz*long+rz*lateral;c.x+=c.vx*dt;c.z+=c.vz*dt;c.speed=long;
    this.wallCollision(previous);if(this.state!=='play')return;
    speed=Math.hypot(c.vx,c.vz);c.speed=c.vx*Math.sin(c.heading)-c.vz*Math.cos(c.heading);this.distance+=distance(previous,c);this.stats.topSpeed=Math.max(this.stats.topSpeed,speed);this.stats.maxSpeed=this.stats.topSpeed;c.gear=clamp(1+Math.floor(Math.abs(c.speed)/24),1,6);c.rpm=clamp((Math.abs(c.speed)%24)/24*.65+.25,0,1);
    const slip=Math.abs(lateral)/Math.max(1,Math.abs(long));c.drifting=speed>22&&Math.abs(c.steer)>.3&&(handbrake||slip>.2);
    if(c.drifting){const amount=dt*speed*.85;this.stats.driftScore+=amount;this.score+=amount*this.combo;this.comboTime=4;this.driftAccumulator+=dt;if(this.driftAccumulator>=.7){this.driftAccumulator=0;this.combo=clamp(this.combo+.15,1,5);this.emit('drift',{bonus:Math.round(amount*this.combo/dt*.7)});}}else this.driftAccumulator=0;
    if(speed>35)this.score+=dt*(speed-30)*.3*this.combo;
    for(const npc of this.traffic){this.updateNpc(npc,dt,false);this.collideNpc(npc,false);if(this.state!=='play')return;}
    for(const npc of this.police){this.updateNpc(npc,dt,true);this.collideNpc(npc,true);if(this.state!=='play')return;}
    for(let i=this.roadblocks.length-1;i>=0;i--){const rb=this.roadblocks[i];rb.age+=dt;rb.life-=dt;for(const npc of rb.cars)this.collideNpc(npc,true);if(rb.life<=0)this.roadblocks.splice(i,1);if(this.state!=='play')return;}
    let observed=false,close=0;for(const npc of this.police){const d=distance(c,npc);if(this.wanted>0&&visible(c,npc))observed=true;if(d<20&&this.wanted>0)close++;}
    if(this.wanted>0){this.chaseLost=observed?0:this.chaseLost+dt;if(this.chaseLost>11&&this.escapeCooldown<=0){this.stats.escapes++;const bonus=750*this.wanted;this.score+=bonus;this.heat=8;this.wanted=0;this.chaseLost=0;this.escapeCooldown=13;this.busted=0;this.emit('escaped',{bonus});this.emit('toast',{title:'POURSUITE SEMÉE',subtitle:`+${bonus} points · Profitez du répit`});}}
    this.heat=clamp(this.heat+(speed>50?(speed-50)*.009:.025)*dt+(c.boosting?.25*dt:0),0,120);
    const targetWanted=this.escapeCooldown>0&&this.wanted===0?0:clamp(1+Math.floor(this.heat/24),1,5);if(targetWanted!==this.wanted){this.wanted=targetWanted;this.emit('wanted',{wanted:this.wanted,heat:this.heat});if(this.wanted>0)this.emit('siren',{wanted:this.wanted});}
    const capture=close>0&&speed<11?dt*(.13+close*.065):-(.23*dt);this.busted=clamp(this.busted+capture,0,1);if(this.busted>=1){this.finish('busted');return;}
    this.policeSpawnTime-=dt;const desiredPolice=this.wanted===0?2:Math.min(9,2+this.wanted);if(this.police.length<desiredPolice&&this.policeSpawnTime<=0){this.spawnPolice();this.policeSpawnTime=3;}
    // Despawn only distant units. No visible police teleportation or rubber-band repositioning.
    if(this.police.length>desiredPolice){const i=this.police.findIndex(p=>distance(p,c)>420);if(i>=0)this.police.splice(i,1);}
    this.roadblockTime-=dt;if(this.wanted>=3&&this.roadblockTime<=0){this.newRoadblock();this.roadblockTime=16-this.wanted;}
    this.checkpointTime=Math.max(0,this.checkpointTime-dt);if(distance(c,this.checkpoint)<24){this.checkpoints++;const bonus=Math.round((900+this.checkpointTime*12)*this.combo);this.score+=bonus;c.health=Math.min(c.maxHealth,c.health+14);c.nitro=clamp(c.nitro+38,0,100);this.heat=clamp(this.heat+7,0,120);this.emit('checkpoint',{bonus,total:this.checkpoints});this.emit('toast',{title:'LIVRAISON EXPRESS',subtitle:`+${bonus} points · +14 intégrité · +38 nitro`});this.nextCheckpoint();}
    if(c.health<=0)this.finish('destroyed');
  }
}
