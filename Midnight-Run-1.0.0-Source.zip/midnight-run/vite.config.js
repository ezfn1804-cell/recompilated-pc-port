import {defineConfig} from 'vite';
export default defineConfig({
  base:'./',
  build:{chunkSizeWarningLimit:750},
  server:{port:5180,strictPort:true},
  preview:{port:5181,strictPort:true}
});
