import {spawnSync} from 'node:child_process';
import {readFileSync,writeFileSync,copyFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {createRequire} from 'node:module';
import {fileURLToPath} from 'node:url';
const require=createRequire(import.meta.url);
const project=fileURLToPath(new URL('../',import.meta.url));
process.chdir(project);
const builder=require.resolve('electron-builder/out/cli/cli.js');
const result=spawnSync(process.execPath,[builder,'--win','portable','--x64'],{
  cwd:project,stdio:'inherit',
  env:{...process.env,ELECTRON_BUILDER_COMPRESSION_LEVEL:process.env.ELECTRON_BUILDER_COMPRESSION_LEVEL||'7'}
});
if(result.error)throw result.error;
if(result.status!==0)process.exit(result.status||1);
const pkg=JSON.parse(readFileSync('package.json','utf8'));
const name=`Midnight-Run-${pkg.version}-Windows-x64.exe`;
const data=readFileSync(`release/${name}`);
const sha256=createHash('sha256').update(data).digest('hex');
writeFileSync('release/SHA256SUMS.txt',`${sha256}  ${name}\n`);
copyFileSync('desktop/THIRD_PARTY_NOTICES.txt','release/THIRD_PARTY_NOTICES.txt');
writeFileSync('release/LIRE-MOI.txt',`MIDNIGHT RUN ${pkg.version}\n\nWindows 10 / 11, 64 bits.\nLancez ${name} par double-clic. Aucun serveur, connexion ou installation de Node.js nécessaire.\n\nZQSD / WASD / flèches : accélérer, freiner / reculer, diriger\nEspace : frein à main / drift\nMaj : nitro\nC : changer de caméra\nR : remettre la voiture sur la route\nÉchap : pause\nF11 : plein écran\n\nLe jeu et ses polices sont embarqués. Les records restent dans le profil local de l’application.\nExécutable de développement non signé. Construit depuis Linux ; lancement natif Windows à vérifier sur Windows.\n\nSHA-256 : ${sha256}\n`);
const limit=100*1024*1024;
console.log(`\nWindows portable prêt : release/${name}\nTaille : ${data.length} octets\nSHA-256 : ${sha256}`);
if(data.length>=limit)console.warn('Le fichier dépasse la limite GitHub Git de 100 Mio. Publier via un asset de Release, ou augmenter la compression avant un envoi Git.');
