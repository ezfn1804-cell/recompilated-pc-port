const {app,BrowserWindow,Menu,ipcMain,screen}=require('electron');
const path=require('node:path');
let window;
app.setAppUserModelId('games.midnightrun.pursuit');
function createWindow(){
  const bounds=screen.getPrimaryDisplay().workAreaSize;
  window=new BrowserWindow({
    width:Math.min(1600,bounds.width),height:Math.min(960,bounds.height),
    minWidth:960,minHeight:640,backgroundColor:'#050912',title:'MIDNIGHT RUN',
    icon:path.join(__dirname,'icon.png'),autoHideMenuBar:true,show:false,
    webPreferences:{
      preload:path.join(__dirname,'preload.cjs'),nodeIntegration:false,
      contextIsolation:true,sandbox:true,webSecurity:true
    }
  });
  Menu.setApplicationMenu(null);
  window.webContents.setWindowOpenHandler(()=>({action:'deny'}));
  window.webContents.on('will-navigate',event=>event.preventDefault());
  window.webContents.session.setPermissionRequestHandler((_contents,_permission,callback)=>callback(false));
  window.once('ready-to-show',()=>window.show());
  window.loadFile(path.join(__dirname,'../dist/index.html'));
}
ipcMain.handle('toggle-fullscreen',event=>{
  if(window&&!window.isDestroyed()&&event.sender===window.webContents)window.setFullScreen(!window.isFullScreen());
});
app.whenReady().then(createWindow);
app.on('window-all-closed',()=>app.quit());
