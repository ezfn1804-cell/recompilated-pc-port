const {contextBridge,ipcRenderer}=require('electron');
const api={toggleFullscreen:()=>ipcRenderer.invoke('toggle-fullscreen')};
contextBridge.exposeInMainWorld('midnightDesktop',api);
contextBridge.exposeInMainWorld('neonDesktop',api);
